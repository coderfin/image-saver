(async () => {
  const APP_ID = '18487b61-530b-4f90-9dee-53151ecc6dc1';
  const DATABASE_NAME = 'inbox';
  const CREATE_ACCOUNT_LINK = 'https://coderfin.github.io/lui-admin/#/signup';
  const INBOX_LINK = 'https://coderfin.github.io/lui-admin/#/inbox';

  const session = await userbase.init({
    appId: APP_ID,
    allowServerSideEncryption: true,
  });

  // Get the user if they are already signed in otherwise set to null and require sign in.
  let user = session.user || null;

  let tabId = null;
  const logMessageToUser = ({
    message,
    object,
    group,
    closeGroup = false,
    type = 'log',
  }) => {
    if (tabId) {
      chrome.tabs.sendMessage(
        tabId,
        JSON.stringify({
          message,
          object,
          group,
          closeGroup,
          type,
        })
      );
    } else {
      chrome.tabs.query(
        { active: true, windowId: chrome.windows.WINDOW_ID_CURRENT },
        (tabs) => {
          tabId = tabs[0].id;

          chrome.tabs.executeScript(tabId, { file: 'log-message.js' }, () => {
            logMessageToUser({
              message,
              object,
              group,
              closeGroup,
              type,
            });
          });
        }
      );
    }
  };

  const handleSaveImage = async ({ pageUrl, srcUrl }) => {
    const itemId = uuidV4();

    const item = { pageUrl };

    if (!srcUrl.startsWith('data:')) {
      item.srcUrl = srcUrl;
    }

    await userbase.insertItem({
      databaseName: DATABASE_NAME,
      item,
      itemId,
    });

    if (srcUrl.startsWith('data:')) {
      const file = await urlToFile({ url: srcUrl, filename: itemId });

      await userbase.uploadFile({
        databaseName: DATABASE_NAME,
        itemId,
        file,
      });
    }

    logMessageToUser({
      message: 'Image Saved',
      object: {
        srcUrl,
      },
    });
  };

  const handleSignIn = async () => {
    const username = prompt('Username');
    const password = prompt('Password');

    if (username && password) {
      try {
        user = await window.userbase.signIn({ username, password });

        userbase.openDatabase({
          databaseName: DATABASE_NAME,
          changeHandler: () => {},
        });

        createSignedInMenus();
        updateSaveImageMenu();

        logMessageToUser({
          message: `Welcome ${user.username} \n Save an image by right clicking or using 'command+shift+L'`,
          group: `Welcome to Lui's Image Search`,
        });
      } catch (error) {
        logMessageToUser({
          message: 'ERROR',
          object: error,
          type: 'error',
        });
      }
    } else {
      logMessageToUser({
        message: 'Please enter a valid username and password.',
        type: 'warn',
      });
    }
  };

  chrome.runtime.onMessage.addListener((response) => {
    if (response && response.src && response.pageUrl) {
      handleSaveImage({
        srcUrl: response.src,
        pageUrl: response.pageUrl,
      });
    } else if (
      response &&
      response.message &&
      response.message === 'not found'
    ) {
      logMessageToUser({
        message: 'Could not find image in active (focused) element.',
        type: 'warn',
      });
    }
  });

  chrome.commands.onCommand.addListener((command) => {
    if (command === 'save-image') {
      if (user) {
        chrome.tabs.executeScript({
          file: 'active-element.js',
        });
      } else {
        handleSignIn();
      }
    }
  });

  const parentContextMenu = chrome.contextMenus.create({
    title: "🖼️ Lui's Image Saver",
    contexts: ['all'],
  });

  // Helper functions
  const urlToFile = async ({ url, filename }) => {
    const response = await fetch(url);
    const buffer = await response.arrayBuffer();
    const mimeType = url
      .split(',')[0]
      .match(/[^:\s*]\w+\/[\w-+\d.]+(?=[;| ])/)[0];

    return new File([buffer], filename, { type: mimeType });
  };

  const uuidV4 = () => {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
      (
        c ^
        (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
      ).toString(16)
    );
  };

  // 💾 Save Image
  const saveImageContextMenu = chrome.contextMenus.create({
    title: '💾 Save Image (command+shift+L)',
    contexts: ['image'],
    enabled: !!user,
    onclick: handleSaveImage,
    parentId: parentContextMenu,
  });

  const updateSaveImageMenu = () => {
    chrome.contextMenus.update(saveImageContextMenu, {
      enabled: !!user,
    });
  };

  // 📥 View Image Inbox
  chrome.contextMenus.create({
    title: '📥 View Inbox',
    contexts: ['all'],
    onclick: () => {
      chrome.tabs.create({ url: INBOX_LINK });
    },
    parentId: parentContextMenu,
  });

  // Seperator ---
  chrome.contextMenus.create({
    type: 'separator',
    contexts: ['all'],
    parentId: parentContextMenu,
  });

  // 👤 Account
  let signInContextMenu, createAccountContextMenu, signOutContextMenu;
  const createSignedOutMenus = () => {
    if (signOutContextMenu) {
      chrome.contextMenus.remove(signOutContextMenu);
    }

    signInContextMenu = chrome.contextMenus.create({
      title: '⏻ Sign in (command+shift+L)',
      contexts: ['all'],
      onclick: handleSignIn,
      parentId: parentContextMenu,
    });

    createAccountContextMenu = chrome.contextMenus.create({
      title: '👤 Create account',
      contexts: ['all'],
      onclick: () => {
        chrome.tabs.create({ url: CREATE_ACCOUNT_LINK });
      },
      parentId: parentContextMenu,
    });
  };

  const createSignedInMenus = () => {
    if (signInContextMenu) {
      chrome.contextMenus.remove(signInContextMenu);
      chrome.contextMenus.remove(createAccountContextMenu);
    }

    signOutContextMenu = chrome.contextMenus.create({
      title: '⏻ Sign out',
      contexts: ['all'],
      onclick: async () => {
        try {
          const username = user.username;

          user = await window.userbase.signOut();

          createSignedOutMenus();
          updateSaveImageMenu();

          logMessageToUser({
            message: `${username}, you have successfully signed out`,
            closeGoup: true,
          });
        } catch (error) {
          logMessageToUser({
            message: 'ERROR',
            object: error,
            type: 'error',
          });
        }
      },
      parentId: parentContextMenu,
    });
  };

  // Create initial menus
  if (user) {
    createSignedInMenus();
  } else {
    createSignedOutMenus();
  }
})();
