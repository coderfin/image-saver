{
  console.image = function ({ url, sizePercent = 20 }) {
    const image = new Image();

    image.onload = function () {
      const style = `
        font-size: 1px;
        padding: ${(this.height / 100) * sizePercent}px ${
        (this.width / 100) * sizePercent
      }px;
        background: url("${url}") no-repeat;
        background-size: contain;
      `;

      console.log('%c ', style);
    };

    image.src = url;
  };

  // #7A6BB0 // purple
  // #009DE2 // blue
  // #4F2529 // maroon
  // #233943 // black-blue
  // #121c21 // darker black-blue
  // #BCE2E9 // light blue
  chrome.runtime.onMessage.addListener((request) => {
    const { group, closeGroup, message, object, type } = JSON.parse(request);

    if (group) {
      console.group(group);
    }

    if (closeGroup) {
      console.groupEnd();
    }

    const style = `
        background: #7A6BB0;
        color: #121c21;
        font-size: 15px;
        font-weight: bold;
        padding: 0.5em;
    `;

    if (object && object.srcUrl) {
      const srcUrl = object.srcUrl;
      delete object.srcUrl;

      if (Object.keys(object).length) {
        console[type](`%c ${message}`, style, object);
      } else {
        console[type](`%c ${message}`, style);
      }

      console.image({ url: srcUrl });
    } else if (object) {
      console[type](`%c ${message}`, style, object);
    } else {
      console[type](`%c ${message}`, style);
    }
  });
}
