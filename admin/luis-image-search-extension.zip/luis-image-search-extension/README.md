# luis-image-search-extension

Chrome Extension - An interface to allow Lui's parents to add images from any website to his stored images inbox.

Generating a key:

https://stackoverflow.com/questions/37317779/making-a-unique-extension-id-and-key-for-chrome-extension

openssl genrsa 2048 | openssl pkcs8 -topk8 -nocrypt -out key.pem

Key:

openssl rsa -in key.pem -pubout -outform DER | openssl base64 -A

Extension ID:

openssl rsa -in key.pem -pubout -outform DER | shasum -a 256 | head -c32 | tr 0-9a-f a-p
