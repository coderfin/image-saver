{
  if (document.activeElement && document.activeElement.src) {
    chrome.runtime.sendMessage({
      src: document.activeElement.src,
      pageUrl: window.location.href,
    });
  } else if (
    document.activeElement &&
    document.activeElement.querySelector('img')
  ) {
    chrome.runtime.sendMessage({
      src: document.activeElement.querySelector('img').src,
      pageUrl: window.location.href,
    });
  } else {
    chrome.runtime.sendMessage({
      message: 'not found',
    });
  }
}
